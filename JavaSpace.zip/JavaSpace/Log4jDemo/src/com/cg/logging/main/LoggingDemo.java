package com.cg.logging.main;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LoggingDemo{
	static Logger logger=Logger.getLogger(LoggingDemo.class);
public static void main(String args[]){
	/*PropertyConfigurator.configure(properties);*/
	logger.debug("Debugger app");
	logger.info("Info printed");
	/*logger.*/
	
}
	
}