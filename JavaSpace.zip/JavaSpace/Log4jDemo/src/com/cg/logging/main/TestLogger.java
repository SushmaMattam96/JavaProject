package com.cg.logging.main;

import org.apache.log4j.Logger;

public class TestLogger {
	static Logger logger=Logger.getLogger(TestLogger.class);
	public static void testlogging(int i,int j){
		logger.debug("In test");
		logger.info("Info called");
		logger.warn("Warn called");
		logger.error("error");
	}
}
