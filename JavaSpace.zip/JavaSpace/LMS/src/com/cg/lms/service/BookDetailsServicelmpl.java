package com.cg.lms.service;

import com.cg.lms.dao.BookDetailsDAO;
import com.cg.lms.dao.BookDetailsDAOImpl;
import com.cg.lms.exception.LMSException;
import com.cg.lms.model.BookDetails;

public class BookDetailsServicelmpl implements BookDetailsService {
	BookDetailsDAO bookdetailsdao= new BookDetailsDAOImpl();

	@Override
	public void createbookdetails() throws LMSException {
		
		
	}

	@Override
	public int insertbookdetails(BookDetails bookdetails) throws LMSException {
		
		return bookdetailsdao.insertbookdetails(bookdetails);
	}

	@Override
	public int updatebookdetails(BookDetails bookdetails) throws LMSException {
		
		return bookdetailsdao.updatebookdetails(bookdetails);
	}
	

}
