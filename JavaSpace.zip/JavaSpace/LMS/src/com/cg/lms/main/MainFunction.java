package com.cg.lms.main;

import java.util.Scanner;

import com.cg.lms.dao.BookDetailsDAO;
import com.cg.lms.dao.BookDetailsDAOImpl;
import com.cg.lms.exception.LMSException;
import com.cg.lms.model.BookDetails;

public class MainFunction {
	public static void main(String args[]) throws LMSException {
		System.out.println("=====Menu======");
		System.out.println("1.Create table");
		System.out.println("2.Insert Bookdetails into Table");
		System.out.println("3.Update Bookdetails into table");
		Scanner scan = new Scanner(System.in);
		int ch = scan.nextInt();
		BookDetails bookdetails = new BookDetails();
		BookDetailsDAO bookdaoimpl = new BookDetailsDAOImpl();
		switch (ch) {
		case 1:
			try {
				bookdaoimpl.createbookdetails();
				System.out.println("table created");
			} catch (LMSException e) {
				System.out.println("No table created");
			}
			break;
		case 2:
			System.out.println("Enter the Book Name:");
			scan.nextLine();
			String bookname = scan.nextLine();
			System.out.println("Enter the Book author:");
			String bookauthor = scan.nextLine();
			System.out.println("Enter the cost of book:");
			Double bookcost = scan.nextDouble();

			bookdetails.setName(bookname);
			bookdetails.setAuthor(bookauthor);
			bookdetails.setCost(bookcost);

			try {
				bookdaoimpl.insertbookdetails(bookdetails);
				System.out.println("Records inserted");
			} catch (LMSException e) {
				System.err.println("No records to inserted");
			}
			break;
		case 3:
			System.out.println("Enter id");
			int Id = scan.nextInt();
			System.out.println("Enter Cost");
			double bookcosts = scan.nextDouble();

			bookdetails.setId(Id);
			bookdetails.setCost(bookcosts);
			try {
				bookdaoimpl.updatebookdetails(bookdetails);
				System.out.println("Records Updated");
			} catch (LMSException e) {
				System.err.println("No records to Updated");
			}
			break;
		default:
			System.out.println("Enter valid number");
			break;
		}
		scan.close();
	}

}
