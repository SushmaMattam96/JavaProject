package com.cg.lms.dao;

import com.cg.lms.exception.LMSException;
import com.cg.lms.model.BookDetails;

public interface BookDetailsDAO {
	void createbookdetails()throws LMSException;
	int insertbookdetails(BookDetails bookdetails) throws LMSException;
	int updatebookdetails(BookDetails bookdetails)throws LMSException;
	

}
