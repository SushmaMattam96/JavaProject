package com.cg.lms.dao;

public interface LMSQueryMapper {
	public static final String createQuery="CREATE TABLE BookDetails(Id NUMBER PRIMARY KEY,BookName VARCHAR2(20),"
			+ "BookAuthor VARCHAR2(20),BookCost DECIMAL(8,3))";
	public static final String sequenceQuery ="CREATE SEQUENCE Bookdetails_seq start with 1000";
	public static final String insertQuery = "INSERT INTO BookDetails VALUES(Bookdetails_seq.nextval,?,?,?)";
	public static final String updateQuery = "UPDATE BookDetails set BookCost=? WHERE Id=?";
}
