package com.cg.lms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.cg.lms.exception.LMSException;
import com.cg.lms.model.BookDetails;
import com.cg.lms.utility.BookDetailsUtility;


public class BookDetailsDAOImpl implements BookDetailsDAO {
	PreparedStatement statement=null;
	Connection connection=null;
	int result=0;
	public void createbookdetails()throws LMSException{
		connection=BookDetailsUtility.getConnection();
		try{
			statement=connection.prepareStatement(LMSQueryMapper.createQuery);
			statement.execute();
		}catch(SQLException e)
		{
			System.out.println("Prepared Statement is not created");
		}
		try{ 
			statement=connection.prepareStatement(LMSQueryMapper.sequenceQuery);
			statement.execute();
		}catch(SQLException e)
		{
			System.out.println("Prepared Statement is not create");
		}
	
	}

	@Override
	public int insertbookdetails(BookDetails bookdetails) throws LMSException {
		connection=BookDetailsUtility.getConnection();
		try{
			statement=connection.prepareStatement(LMSQueryMapper.insertQuery);
			statement.setString(1,bookdetails.getName());
			statement.setString(2,bookdetails.getAuthor());
			statement.setDouble(3,bookdetails.getCost());
			result=statement.executeUpdate();
		}catch(SQLException e)
		{
			System.out.println("Prepared Statement is not created");
		}finally {
			try{
				statement.close();
			}catch(SQLException e)
			{
				throw new LMSException("Statement closed");
			}
			try{
				connection.close();
			}catch(SQLException e)
			{
				throw new LMSException("Connection wasn't closed");
			}
		}	
		return result;
	}

	@Override
	public int updatebookdetails(BookDetails bookdetails) throws LMSException {
		connection=BookDetailsUtility.getConnection();
		try{
			statement=connection.prepareStatement(LMSQueryMapper.updateQuery);
			statement.setDouble(1,bookdetails.getCost());
			statement.setInt(2,bookdetails.getId());
			result=statement.executeUpdate();
		}catch(SQLException e)
		{
			System.out.println("Prepared Statement is not created");
		}finally {
			try{
				statement.close();
			}catch(SQLException e)
			{
				throw new LMSException("Statement closed");
			}
			try{
				connection.close();
			}catch(SQLException e)
			{
				throw new LMSException("Connection wasn't closed");
			}
		}
		return result;
	}

}
