package com.cg.lms.model;

public class BookDetails {
	private int id;
	private String name;
	private String author;
	private Double cost;
	
	public BookDetails(){
		
	}
	
	public BookDetails(int id, String name, String author, Double cost) {
		super();
		this.id = id;
		this.name = name;
		this.author = author;
		this.cost = cost;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Double getCost() {
		return cost;
	}
	public void setCost(Double cost) {
		this.cost = cost;
	}	
}

