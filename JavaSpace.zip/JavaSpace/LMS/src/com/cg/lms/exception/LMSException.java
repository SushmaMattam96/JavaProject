package com.cg.lms.exception;

public class LMSException extends Exception {
	public LMSException(String msg)
	{
		super(msg);
	}

}
