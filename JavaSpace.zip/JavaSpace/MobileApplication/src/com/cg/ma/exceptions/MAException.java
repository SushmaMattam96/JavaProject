package com.cg.ma.exceptions;
public class MAException extends Exception {

	public MAException(String message) {
		super(message);
	}
}