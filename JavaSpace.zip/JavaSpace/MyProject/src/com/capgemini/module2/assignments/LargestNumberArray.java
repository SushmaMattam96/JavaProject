package com.capgemini.module2.assignments;

import java.util.Scanner;

public class LargestNumberArray {
	public static int getlargestvalueofarray(int[] arr){
		
		int value=0;
		for(int i=0;i<arr.length;i++)
		{
			if(value<arr[i])
			{
				value=arr[i];
			}
		}
		return value;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array size:");
		int input=sc.nextInt();
		int arr[]=new int[input];
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("enter elements"); 
			arr[i]=sc.nextInt();
		}
		int result=getlargestvalueofarray(arr);
		System.out.println(result);
		
		
	}
}
