package com.capgemini.module2.assignments;

public class FindVowelInString {
	public static void main(String args[]){
		
	}

}
