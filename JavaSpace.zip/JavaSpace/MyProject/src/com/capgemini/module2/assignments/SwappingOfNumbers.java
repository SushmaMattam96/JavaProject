package com.capgemini.module2.assignments;

import java.util.Scanner;

public class SwappingOfNumbers {
	public static void swappingofnumbers(int value1,int value2) 
	{
		value1=value1+value2;
		value2=value1-value2;
		value1=value1-value2;
		System.out.println("After swapping: " + value1 + "," + value2);
	}
	public static void main(String args[])
	{
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the number");
		int value1=scan.nextInt();
		System.out.println("Enter the Second Number");
		int value2=scan.nextInt();
		swappingofnumbers(value1, value2);
		scan.close();
	}

}
