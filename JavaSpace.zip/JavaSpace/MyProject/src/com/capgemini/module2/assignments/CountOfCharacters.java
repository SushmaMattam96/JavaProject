package com.capgemini.module2.assignments;

import java.util.Scanner;

public class CountOfCharacters {
	public static void getcountofsimilarchars(String ch)
	{
		int count=0;
		int i,j;
		char chart = 0;
		for(i=0;i<ch.length();i++)
		{
			chart= ch.charAt(i);
			
			for(j=i+1;j<ch.length();j++)
			{
				
				if(chart==ch.charAt(j))
				{
					count++;
				}
			}
		}
		System.out.println("The repeated characters are:" + chart + " " + count);
		
	}
	public static void main(String args[])
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the String : ");
		String ch=scan.nextLine();
		getcountofsimilarchars(ch);
	}

}
