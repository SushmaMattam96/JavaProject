package com.capgemini.module2.assignments;
import java.util.Scanner;
public class CountClass {
	
	public static int getCount(String Input)
	{
		int val = Input.length();
		int count=1;
		for(int i=0; i<val;i++)
		{
			if(Input.charAt(i)==' ')
			{
				count++;
			}
		}
		/*Input = Input + '\0';
		int count = 0;
		 for (int i = 0; Input.charAt(i) != '\0'; i++) {
		        count++;
		    }
		 return count;*/
	return count;
	
	}
	public static void main(String[] args) {
	
		Scanner Scanner= new Scanner(System.in);
		System.out.println("Enter text");
		String in=Scanner.nextLine();
		CountClass len=new CountClass();
		int count=len.getCount(in);
		System.out.println("The COUNT is :"+count);
	}

}
