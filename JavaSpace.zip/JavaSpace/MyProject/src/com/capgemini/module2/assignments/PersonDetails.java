package com.capgemini.module2.assignments;

public class PersonDetails {
		String Firstname;
		String Lastname;
		char Gender;
		String PhoneNo;		

		public String getFristname() {
			return Firstname;
		}
		public void setFristname(String firstname) {
			Firstname = firstname;
		}
		public String getLastname() {
			return Lastname;
		}
		public void setLastname(String lastname) {
			Lastname = lastname;
		}
		public char getGender() {
			return Gender;
		}
		public void setGender(char gender) {
			Gender = gender;
		}
		public String getPhoneNo() {
			return PhoneNo;
		}
		public void setPhoneNo(String phoneNo) {
			PhoneNo = phoneNo;
		}
		public PersonDetails() {
			Firstname="Sushma";
			Lastname="Mattam";
			Gender='F';
			PhoneNo="9764133093";
		}
		public PersonDetails(String firstname, String lastname, char gender,String Phoneno) {
			super();
			Firstname = firstname;
			Lastname = lastname;
			Gender = gender;
			PhoneNo=Phoneno;
		}
		
		public void display(){
			 System.out.println("\nFirstName :" +Firstname+"\nLastName :"+Lastname+"\nGender :"+Gender+"\nPhoneNo:"+PhoneNo);
				
		}

			public static void main(String[] args) {
				PersonDetails person= new PersonDetails();
				person.display();
				PersonDetails person1= new PersonDetails("Abdulla","Karjikar",'M',"952368417");
				person1.display();
			
			// TODO Auto-generated method stub
				
		}
			
			
}

