package com.capgemini.module2.assignments;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;

public class TreeMapAvgProducts {
	public static double getavgofproducts(HashMap<String,Double> map,String arr[])
	{
		double Avg=0;
		int Count=0;
		Set<Entry<String,Double>> set=map.entrySet();
		Iterator<Entry<String,Double>> iter=set.iterator();
		while(iter.hasNext())
		{
			Entry<String, Double> Data=iter.next();
			String ProductName=Data.getKey();
			Double Price=Data.getValue();
			for (int i = 0; i < arr.length; i++) {
				if(ProductName.equals(arr[i]))
				{
					Avg=Avg+Price;
					Count++;
				}
			}
		}
		/*Result=Avg/Count;*/
		/*maps.put(result);*/
		/*System.out.println(Count);
		System.out.println(Avg);*/
		return Avg/Count;
	}
	public static void main(String args[])
	{
		HashMap<String,Double> map=new HashMap<String, Double>();
		 map.put("TV", 20000.60);
		 map.put("AC", 75000.68);
		 map.put("Refridgerator", 30000.25);
		 map.put("Laptop", 25000.56);
		 map.put("Mobile", 15000.34);
		 map.put("WashingMachine", 27000.57);
		 System.out.println("Enter the array size:");
		 Scanner scan=new Scanner(System.in);
		 int input=scan.nextInt();
		 String arr[]=new String[input];
		 scan.nextLine();
		 for(int i=0;i<arr.length;i++)
		 {
			 
			 System.out.println("Enter the Products");
			 arr[i]=scan.nextLine();
		 }
		 double Avg = TreeMapAvgProducts.getavgofproducts(map,arr);
		 System.out.println("Average is:" + Avg);
	}
}
