package com.capgemini.module2.assignments;

import java.util.Scanner;

public class ReverseString {
	public static String getReverseString(String str)
	{
		StringBuilder strng= new StringBuilder(str);
		StringBuilder Reverse=strng.reverse();
		String Newstring=Reverse.toString();
		int len=Newstring.length();
		String newstrng="";
		for(int i=0;i<len;i++)
		{
		
			if(i!=len-1)
			{
				newstrng+=Newstring.charAt(i)+"-";
			}
			else{
				newstrng+=Newstring.charAt(i);
			}
			
		}
		return newstrng;	
	}
	public static void main(String args[])
	{
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the string:");
		String str = scan.nextLine();
		String result=getReverseString(str);
		System.out.println(result);
	}

}
