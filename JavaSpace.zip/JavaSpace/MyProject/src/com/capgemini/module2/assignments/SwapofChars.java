package com.capgemini.module2.assignments;

public class SwapofChars {
	public static String swapofchar(String ch)
	{
		int i=0,j=0;
		 int temp=0;
		 int[] arr = null;
		for(i=0;i<ch.length();i++)
		{
			for(j=1;j<ch.length()/2;j++)
			{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
		
		System.out.println("After swapping string is : " );
		return ch;
		
	}
	public static void main(String args[]) 
	{
		
		int[] arr= new int[50];
		
	}
	

}
