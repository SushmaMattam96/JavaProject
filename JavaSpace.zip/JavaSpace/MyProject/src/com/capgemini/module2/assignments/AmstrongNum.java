package com.capgemini.module2.assignments;

import java.util.Scanner;

public class AmstrongNum {
	public static void getAmstrongNo(String in) {
		int rev = 0, temp, cube;
		int count = in.length();
		int number = Integer.parseInt(in);
		int temp1 = number;
		while (number != 0) {
			cube = 1;
			temp = number % 10;
			for (int i = 0; i < count; i++) {
				cube *= temp;
			}
			rev += cube;
			number = number / 10;

		}
		if (temp1 == rev) {
			System.out.println("Armstrong");
		} else {
			System.out.println("Not Armstrong");
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter armstrong number:");
		String in = scanner.nextLine();
		getAmstrongNo(in);

	}

}
