package com.capgemini.module2.assignments;

public class PersonClass {
	String Firstname;
	String Lastname;
	char Gender;

	public String getFristname() {
		return Firstname;
	}
	public void setFristname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	public PersonClass() {
		Firstname="Sushma";
		Lastname="Mattam";
		Gender='F';
	}
	public PersonClass(String firstname, String lastname, char gender) {
		super();
		Firstname = firstname;
		Lastname = lastname;
		Gender = gender;
	}
	
	public void display(){
		 System.out.println("\nFirstName :" +Firstname+"\nLastName :"+Lastname+"\n Gender :"+Gender);
			
	}

		public static void main(String[] args) {
			PersonClass person= new PersonClass();
			person.display();
			PersonClass person1= new PersonClass("Abdulla","Karjikar",'M');
			person1.display();
		
		// TODO Auto-generated method stub
			
	}
}
