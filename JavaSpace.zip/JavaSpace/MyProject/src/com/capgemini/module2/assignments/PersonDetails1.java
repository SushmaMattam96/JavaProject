package com.capgemini.module2.assignments;

public class PersonDetails1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
