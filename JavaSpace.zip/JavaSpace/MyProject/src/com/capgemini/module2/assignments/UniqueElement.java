package com.capgemini.module2.assignments;

public class UniqueElement {
	public static void getuniqueelements(int[] arr)
	{
		
	}

}
