package com.capgemini.module2.assignments;

import java.util.Scanner;
import java.util.regex.Pattern;

public class IPAddressValidation {
	public static String getIPaddressvalue(String str)
	{
		String Rexg="[0-255]{1|2|3}.[0-255]{1|2|3}.[0-255]{1|2|3}.[0-255]{1|2|3}";
		System.out.println(Pattern.matches(Rexg,str));
		return str;
		
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Ip address:");
		String name=sc.nextLine();
		
	}

}
