package com.capgemini.module2.assignments;

import java.util.Scanner;

public class SumOfSquares {
	public static double getSumOfSquares(double input)
	{
		double n=0;
		double sum=0;
		while(input>0)
		{
			n=input%10;
			input=input/10;
			sum= (int) Math.pow(n,2)+sum;
		}
		return sum;
		
	}
	public static void main(String args[]) 
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number");
		int input=scan.nextInt();
		scan.close();
		double sum=getSumOfSquares(input);
		System.out.println("the sum of square of numbers is" + sum );
	}
	

}
