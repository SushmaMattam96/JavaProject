package com.capgemini.module2.assignments;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapDemo{
	public static TreeMap<String,String> fetchData(TreeMap<String,Double> map){
		TreeMap<String, String> maps=new TreeMap<>();
		Set<Entry<String,Double>> set=map.entrySet();
		Iterator<Entry<String,Double>> iter=set.iterator();
		while(iter.hasNext())
		{
			Entry<String, Double> Data=iter.next();
			String StudentName=Data.getKey();
			Double Percent=Data.getValue();
			if(Percent>=60)
			{
				maps.put(StudentName,"Pass");
			} else {
				maps.put(StudentName,"Fail");
			}
		}	
		return maps;
	}
 public static void main(String[] args) {
	 TreeMap<String,Double> map =new TreeMap<>();
	 map.put("Sushma", 75.45);
	 map.put("Vaishnavi", 77.25);
	 map.put("Sirisha", 67.45);
	 map.put("Sanjay", 45.45);
	 map.put("pallavi", 55.45);
	 map.put("Abdulla", 65.45);
	 /*Scanner sc=new Scanner(System.in);*/
	 
	 /*System.out.println("Enter the size of TreeMap:");*/
	 TreeMap<String, String> maps=TreeMapDemo.fetchData(map);
	 System.out.println(maps);
	 
	 
	 
 }
}
