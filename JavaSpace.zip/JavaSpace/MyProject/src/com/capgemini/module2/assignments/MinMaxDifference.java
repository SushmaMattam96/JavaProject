package com.capgemini.module2.assignments;

public class MinMaxDifference {
	public static int getmaxmindifference(int arr[]){
		int value=0;
		int diff=0;
		return 0;
		
	}

}
