package com.capgemini.module2.assignments;

public class PositiveOrNegative {
	public static int x;
	public static void main(String[] args){
		int x= Integer.parseInt(args[0]);
		if (x < 0){
			System.out.println("The Number is Negative");
		} else {
	if(x==0) {
			System.out.println("The Number is Not Positive Nor Negative");	
		} 
		else {
			System.out.println("The Number is Positive");
		}
	}

}
}