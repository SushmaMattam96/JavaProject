package com.capgemini.module2.assignments;

public class FirstLetters {
  public static String  getFirstletter(String string)
  {
	  int str =string.length();
	  StringBuilder builder=new StringBuilder();
	  String arr[]=string.split(" ");
	  for(int i=0; i<arr.length;i++) {
		  String s=arr[i];
		  builder.append(s.charAt(0));
	  }
	  return builder.toString().toUpperCase();
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
