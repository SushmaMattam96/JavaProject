package com.capgemini.module2.assignments;

import java.util.Scanner;

public class SumOfDigits {
	
	public static int getsumofdigits(String str) {
		int sum=0;
		for(int i=0;i<str.length();i++)
		{
			char cha=str.charAt(i);
		if(Character.isDigit(cha))
		{
			int value=Character.getNumericValue(cha);
			sum=sum+value;
		}
		}
		return sum;
		
		
	}
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter string:");
		String ch=scan.nextLine();
		int result=SumOfDigits.getsumofdigits(ch);
		System.out.println(result);
		
	}
}
