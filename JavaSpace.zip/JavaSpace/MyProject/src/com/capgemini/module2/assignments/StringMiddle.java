package com.capgemini.module2.assignments;

import java.util.Scanner;

public class StringMiddle 
{
	public static String getmiddlestring(String name){
		int len=name.length();
		String mid;
		if(len%2!=0)
		{
			 mid=name.substring(len/2,(len/2+1));
			
		}
		else {
			 mid=name.substring(len/2,(len/2+2));
		}
		
		return mid;
	}
	public static void main(String args[])
	{
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the string:");
		String name = scan.nextLine();
		StringMiddle strng = new StringMiddle();
		String result=StringMiddle.getmiddlestring(name);
		System.out.println(result);
	}
}
