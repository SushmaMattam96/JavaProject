package com.capgemini.module2.assignments;
import java.util.Scanner;

public class ReversString {
	public static String getreversechars(String st,int i, int j)
	{
		StringBuilder ch= new StringBuilder(st);
		ch.setCharAt(i,st.charAt(j));
		ch.setCharAt(j,st.charAt(i));
		
		return ch.toString();
		
	}
	
	public static void main(String args[]){
		int i = 0,j=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the string");
		String st=scan.nextLine();
		String result=getreversechars(st,i,j);												
		System.out.println(getreversechars(st, i,(st.length() - 1)));
		
	}
}
