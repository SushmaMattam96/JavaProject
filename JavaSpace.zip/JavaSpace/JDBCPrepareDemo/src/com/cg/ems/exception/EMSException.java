package com.cg.ems.exception;

public class EMSException  extends Exception {
	
	public EMSException(String message) {
		
		super(message);
		
	}

}
