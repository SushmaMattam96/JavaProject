package com.cg.ems.utility;

import java.sql.Connection;

public class JDBCUtility {
	static Connection connection=null;
	public static Connection getConnection() {
	
		return connection;
		
	}

}
