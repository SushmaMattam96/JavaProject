package com.cg.ems.main;

public interface QueryMapper {
	public static final String createQuery="CREATE TABLE jee_jdbcdemo(Id NUMBER PRIMARY KEY,Name VARCHAR2(20),Salary DECIMAL(8,3))";
	public static final String insertQuery="INSERT INTO jee_jdbcdemo VALUES(1198,'Abdulla',30000.44)";
}
