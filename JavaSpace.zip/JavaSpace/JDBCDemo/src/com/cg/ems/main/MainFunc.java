package com.cg.ems.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MainFunc {
	
	Connection connection=null;
	Statement statment=null;
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String username="system";
	String password="corp123";
	
	public void createTable() throws ClassNotFoundException,SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection=DriverManager.getConnection(url,username,password);
		System.out.println("Connected");
		statment=connection.createStatement();
		statment.execute(QueryMapper.createQuery);
		System.out.println("Table created");	
	}
	
	public int insertEmployee() throws ClassNotFoundException,SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection=DriverManager.getConnection(url,username,password);
		statment=connection.createStatement();
		int result=statment.executeUpdate(QueryMapper.insertQuery);
		return result;
	}
	
	public static void main(String args[])
	{
		MainFunc main=new MainFunc();
		try{
			int result=main.insertEmployee();
			System.out.println(result+" Rows Inserted into table");
			
		}catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

}
