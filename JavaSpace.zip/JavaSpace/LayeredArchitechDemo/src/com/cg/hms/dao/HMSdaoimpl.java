package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.Patient;
import com.cg.hms.utility.JdbcUtility;

public class HMSdaoimpl implements HMSDao{
	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;
	
	static Logger logger=Logger.getLogger(HMSdaoimpl.class);
	
	/** 
	 * method      :Add patient details
	 * Arguments   :Its taking model object as a argument 
	 * Return type :This method return the generated id to the user
	 * Author      :Capgemini
	 * Date        :14-Jan-2019
	 */
	
	
	
	
	public int addPatientDetails(Patient patient) throws HMSException{
		
		logger.info("In add patient method");
		connection = JdbcUtility.getConnection();
		logger.info("Connection Obj Created");
		int id=0;
		try{
			statement=connection.prepareStatement(QuerryMapper.insertPatientdetails);
			logger.debug("statment object Created");
			statement.setString(1, patient.getName());
			statement.setString(2, patient.getGender());
			statement.setLong(4, patient.getPhoneNumber());
			statement.setString(3, patient.getProblem());
			statement.executeUpdate();
			
			logger.info("Execute update called");
			statement=connection.prepareStatement(QuerryMapper.getPatientId);

			logger.info("Statement created to get id");
			
			resultSet=statement.executeQuery();
			
			logger.info("result set obj created");
			
			resultSet.next();
			
			id=resultSet.getInt(1);
			
			logger.info("Generate id is"+id);
			
		}catch(SQLException e){
			throw new HMSException("Prepared statement not created");
		}finally{
			try{
			connection.close();
			logger.info("Connection closed");
		}catch(SQLException e){
			logger.error(e.getMessage());
				throw new HMSException("Prepared Statement is not closed");
		}try{
			resultSet.close();
			logger.info("resultset closed");
		}catch(SQLException e){
			logger.error(e.getMessage());
				throw new HMSException("Prepared resultSet is not closed");
		}try{
			statement.close();
			logger.info("Connection closed");
		}catch(SQLException e){
			logger.error(e.getMessage());
				throw new HMSException("Prepared Statement is not closed");
		}
			
		}
		return id;
	


	}
}
