package com.cg.hms.dao;

public interface QuerryMapper {

	public static final String insertPatientdetails ="INSERT INTO PATIENT_DETAILS VALUES(patient_sequence_id.NEXTVAL,?,?,?,?,SYSDATE)";
	String getPatientId = "select patient_sequence_id.currval from dual";

}
