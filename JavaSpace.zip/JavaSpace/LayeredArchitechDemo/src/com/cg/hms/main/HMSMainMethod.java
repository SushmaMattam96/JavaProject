package com.cg.hms.main;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.Patient;
import com.cg.hms.service.HMSService;
import com.cg.hms.service.HMSServiceimpl;

public class HMSMainMethod {

	static Logger logger = Logger.getLogger(HMSMainMethod.class);

	public static void main(String args[]) {
		boolean choiceFlag = false;
		int choice = 0;
		HMSService hmsservice=null;
		PropertyConfigurator.configure("Resources/log4j.properties");

		Scanner scan = null;
		do {

			scan = new Scanner(System.in);
			System.out
					.println("*********Hospital Management System***********");
			System.out.println("1.Book Appoinment");
			System.out.println("2.Get Appoinment");
			System.out.println("3.View all booked Appoinments");
			System.out.println("4.Exit");

			System.out.println("Enter your choice");
			try {
				choice = scan.nextInt();
				choiceFlag = true;
				switch (choice) {
				case 1:
					System.out.println("Enter Name:");
					scan.nextLine();
					String name=scan.nextLine();
					System.out.println("Enter Gender");
					String gender=scan.nextLine();
					System.out.println("Enter PhoneNumber");
					long PhoneNo=scan.nextLong();
					scan.nextLine();
					System.out.println("Enter Problem");
					String problem=scan.nextLine();
					
					Patient patient=new Patient();
					patient.setGender(gender);
					patient.setProblem(problem);
					patient.setPhoneNumber(PhoneNo);
					patient.setName(name);
					hmsservice=new HMSServiceimpl();
					try{
						boolean validate=hmsservice.ValidateField(patient);
						if(validate){
							int id=hmsservice.addPatientDetails(patient);
							System.out.println("Appoinment fixed with id=" +id);
						}
					}catch(HMSException e) {
						System.err.println(e.getMessage());
					}
					break;
					
				case 2:
					break;
				case 3:
					break;
				case 4:
					break;
				default:
					choiceFlag = false;
					System.err.println("Enter valid choice");
					System.out.println("Enter input again");
					break;
				}

			} catch (InputMismatchException e) {
				System.err.println("Enter only digits");
				System.out.println("Enter input again");
				choiceFlag=false;
			}
		} while (!choiceFlag);
		scan.close();
	}
}
