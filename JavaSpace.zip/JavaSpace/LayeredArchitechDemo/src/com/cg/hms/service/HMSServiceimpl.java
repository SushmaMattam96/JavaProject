package com.cg.hms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.hms.dao.HMSDao;
import com.cg.hms.dao.HMSdaoimpl;
import com.cg.hms.exception.HMSException;
import com.cg.hms.model.Patient;

public class HMSServiceimpl implements HMSService {

	HMSDao hmsdao = new HMSdaoimpl();
	List<String> list= new ArrayList<String>();
	/** 
	 * method      :Add patient details
	 * Arguments   :Its taking model object as a argument 
	 * Return type :This method return the generated id to the user
	 * Author      :Capgemini
	 * Date        :14-Jan-2019
	 */

	@Override
	public boolean ValidateField(Patient patient) {
		boolean flag=true;
		if (!checkName(patient.getName())) {
			list.add("Name must Start with capital and should have minimum 5 characters");
		}
		if (!checkGender(patient.getGender())) {
			list.add("Gender must be male or female");
		}
		if (!checkPhoneNo(patient.getPhoneNumber())) {
			list.add("Number must have only 10 Numbers");
		}
		if (!checkProblem(patient.getProblem())) {
			list.add("Problem must have 4 to 10 characters");
		}
		if(list.size()>0)
		{
			flag=false;
			System.out.println(list);
		}
		return flag;
	}

	@Override
	public boolean checkName(String name) {
		String nameRegEx = "[A-Z]{1}[A-Za-z\\s]{4,19}";
		return Pattern.matches(nameRegEx, name);
	}

	@Override
	public boolean checkGender(String gender) {
		String genderRegEx = "MALE|FEMALE|male|female|Female|Male";

		return Pattern.matches(genderRegEx, gender);
	}

	@Override
	public boolean checkPhoneNo(Long PhoneNo) {
		String PhoneNoRegEx = "[6|7|8|9]{1}[0-9]{9}$";

		return Pattern.matches(PhoneNoRegEx, Long.toString(PhoneNo));
	}

	@Override
	public boolean checkProblem(String problem) {
		String Problem = "[A-Za-z]{4,10}";
		return Pattern.matches(Problem, problem);
	}

	@Override
	public int addPatientDetails(Patient patient) throws HMSException {
		// TODO Auto-generated method stub
		return hmsdao.addPatientDetails(patient);
	}

}
