package com.cg.hms.service;

import com.cg.hms.exception.HMSException;
import com.cg.hms.model.Patient;

public interface HMSService {
	
	boolean ValidateField(Patient patient) throws HMSException;
	
	boolean checkName(String name);
	boolean checkGender(String gender);
	boolean checkPhoneNo(Long PhoneNo);
	boolean checkProblem(String problem);
	
	int addPatientDetails(Patient patient) throws HMSException;
	
	

}
